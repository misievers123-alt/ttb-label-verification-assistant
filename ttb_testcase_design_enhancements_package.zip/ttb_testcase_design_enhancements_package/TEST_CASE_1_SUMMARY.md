# Test Case 1 — Incomplete / Partial Application Input

## Purpose

This test case documents a realistic user-entry scenario where the application data is incomplete or partially different from the label text.

The test was created during live testing of the deployed TTB Label Verification Assistant.

## Test Inputs

Application data entered:

- Brand Name: `OLD TOM`
- Class/Type: `Kentucky Straight Bourbon Whiskey`
- Alcohol Content / ABV: `45%`
- Net Contents: `750ml`

Label image contained:

- Brand Name: `OLD TOM DISTILLERY`
- Class/Type: `Kentucky Straight Bourbon Whiskey`
- Alcohol Content / ABV: `45% Alc./Vol.`
- Net Contents: `750 mL`
- Government Warning text

## Observed Result

The app correctly routed the case to:

**Needs Review**

This is the desired behavior for a prototype because the Brand Name input was incomplete compared with the label and the OCR engine selected text from the Government Warning section as the closest match.

## Learned Behavior

The prototype successfully demonstrated human-in-the-loop routing.

Even though most fields matched, the brand-name uncertainty prevented the case from being treated as a clean approval.

## Why This Matters

This is a strong assessment artifact because it shows that the application:

- Does not blindly auto-approve every high-scoring label.
- Flags questionable field-level matches for review.
- Supports the role of the compliance agent as final decision-maker.
- Exposes OCR limitations transparently instead of hiding them.

## Test Case Status

**Passed**

The application behaved appropriately by routing the case to Needs Review.
