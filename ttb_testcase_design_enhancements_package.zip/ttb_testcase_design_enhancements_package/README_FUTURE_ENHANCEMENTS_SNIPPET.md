# README Future Enhancements Snippet

Copy/paste this section into `README.md` under **Future Enhancements**.

```markdown
## Future Enhancements

- Improve field localization by identifying likely label regions (Brand Area, Product Type Area, ABV Area, Net Contents Area, Warning Area) before OCR matching. This would reduce incorrect matches caused by OCR text from unrelated sections of the label.

- Add partial or hierarchical brand-name matching so entries such as `OLD TOM` can be recognized as a likely match to `OLD TOM DISTILLERY` and routed with higher confidence while still preserving human review.

- Add input masking and normalized field entry for application data so values such as `750ml`, `750 ml`, and `750 mL` are standardized before comparison, reducing preventable reviewer input variation.

- Add barcode/UPC scan support so reviewers can optionally capture product identifiers from label or package images and compare them against application or distribution metadata when available.

- Explore barcode/UPC scanning where present on alcohol packaging. Not all labels include scannable product identifiers, so this would be an optional enrichment feature rather than a required validation step.

- Add OCR confidence and image-quality warnings for low-resolution, cropped, angled, or glare-heavy label images.

- Add review-queue prioritization so high-risk issues, such as missing Government Warning text or ABV mismatches, are surfaced before lower-risk formatting differences.
```
