# Design Enhancements Learned From Testing

These enhancements were identified from live prototype testing and should be listed as future improvements rather than rushed into the final submission unless time allows.

## 1. Field-Aware / Region-Based OCR

Improve extraction accuracy by identifying likely label regions before OCR matching:

- Brand Area
- Product Type Area
- ABV / Alcohol Content Area
- Net Contents Area
- Government Warning Area

This would reduce cases where OCR text from an unrelated section of the label is selected as the best match for a field.

Example observed during testing:

- Expected Brand Name: `OLD TOM`
- Detected OCR text: `WOMEN SHOULD NOT`

The detected text came from the Government Warning area, not the brand-name area. The application correctly routed the case to Needs Review, but a future region-aware OCR pipeline could improve the detected brand candidate.

## 2. Partial / Hierarchical Brand Matching

Support brand-name matching where the application value is a partial but reasonable subset of the full label brand.

Example:

- Application value: `OLD TOM`
- Label value: `OLD TOM DISTILLERY`

A future version could recognize this as a likely partial brand match and route it with higher confidence, while still preserving human review for final judgment.

## 3. Input Masking and Normalized Field Entry

Add input masking and normalized field entry for application data so values such as:

- `750ml`
- `750 ml`
- `750 mL`

are standardized before comparison.

This would reduce preventable reviewer input variation and avoid false mismatches caused by spacing, capitalization, or formatting differences in manually entered application data.

## 4. Barcode / UPC Scan Support

Add barcode or UPC scan support so reviewers can optionally capture product identifiers from label or package images and compare them against application or distribution metadata when available.

Caveat:

Not all alcohol labels include scannable product identifiers, so barcode/UPC scanning should be treated as an optional enrichment feature rather than a required validation step.

## 5. OCR Confidence and Quality Warnings

Add image-quality scoring and OCR confidence warnings for:

- Low-resolution images
- Glare
- Cropped labels
- Angled photos
- Missing required regions

This would help agents distinguish between a likely label issue and an image-quality issue.

## 6. Review Queue Prioritization

Use field-level risk to prioritize the human review queue.

Example:

- Missing Government Warning: highest priority
- ABV mismatch: high priority
- Brand partial match: medium priority
- Formatting-only differences: low priority

This would help agents focus attention on the most compliance-relevant exceptions first.
